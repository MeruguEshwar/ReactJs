import React, { Component } from 'react'

export class Homecomponents extends Component {
  render() {
    return (
      <div>
        <h2>HomeComponent</h2>
      </div>
    )
  }
}

export default Homecomponents
