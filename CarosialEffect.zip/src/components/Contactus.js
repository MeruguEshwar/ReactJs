import React from 'react'

function Contactus() {
  return (
    <div>
      <h2>Contact</h2>
    </div>
  )
}

export default Contactus
