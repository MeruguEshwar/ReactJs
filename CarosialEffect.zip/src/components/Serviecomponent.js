import React from 'react'

export default function Serviecomponent() {
  return (
    <div>
      <h2>Service Component</h2>
    </div>
  )
}
